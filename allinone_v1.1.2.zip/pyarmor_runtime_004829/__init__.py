# Pyarmor 9.0.6 (basic), 004829, 2024-12-04T19:03:42.351018
from .pyarmor_runtime import __pyarmor__
